//19/11/2023
#include <cstdio>
#include <cstring>
int main(){
    char str1[10],str2[10];

    if(strcmp(str1,str2) != 0)
        printf("\n\nAs duas strings sao diferentes.");
    else
        printf("\n\nAs duas strings sao iguais.");
    return (0);
}