//
// Created by Robert L Resende on 24/11/24.
//
#include "cstdio"
int main(){

    char re[80];
    printf("Digite o seu nome: ");
    gets(re);
    printf("Oi %s\n",re);
//    system("PAUSE");
    return 0;

}