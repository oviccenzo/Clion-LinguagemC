#include <cstdio>

int main(){

    int contador = 2;

    while(contador < 20){
        printf("Contador = %d\n",contador);
        contador += 2;
    }
    printf("Acabou !!!!\n");
}

