//18/11/2023
//Comando while
//Exemplo2:
#include <cstdio>
int main()
{
    int num;

    num = 800;         //inicializacao
    while(num < 901)  //condicao
    {
        printf("Numero = %d\n",num);
        num ++;
    }
    return 0;
}