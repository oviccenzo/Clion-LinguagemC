//18/11/2023
//Parte 8
//Comando de Repeticao: for, do-while
//Comando for
//Exemplo 1:
#include <cstdio>
int main()
{
    int num;
    for(num = 1; num < 20; num++) {    //inicializacao; condicao; incremento
        printf("Numero = %d\n",num);
    }
    return 0;
}