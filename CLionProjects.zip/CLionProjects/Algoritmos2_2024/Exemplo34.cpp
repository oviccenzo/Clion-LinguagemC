#include <stdio.h>

int main()
{
    char ch;

    printf("Digite algum caracter: ");

    ch = getchar();

    printf("\n A tecla pressionada eh %c.\n", ch);

}
