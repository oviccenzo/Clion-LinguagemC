//
// Created by Robert L Resende on 20/11/24.
//
#include "cstdio"

int main(){

    int n,base,expoente;

    printf("Digite a base de x: ");
    scanf("%d",&base);

    printf("Digite o expoente de y: ");
    scanf("%d",expoente);

    printf("");

    return 0;
}