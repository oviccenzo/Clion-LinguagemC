#include "cstdio"

int main(){


    
    printf("");
    scanf("");


}