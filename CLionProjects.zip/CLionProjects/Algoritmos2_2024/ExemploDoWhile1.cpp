//
// Created by Robert L Resende on 11/10/24.
//

#include <cstdio>
int main(){

    char ch;
    ch ='\0';
    while(ch != 'q'){
        ch = getchar();
    }
    return 0;
}
