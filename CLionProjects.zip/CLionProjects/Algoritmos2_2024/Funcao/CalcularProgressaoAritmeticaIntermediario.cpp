#include <cstdio>

int an,am,n,m,r;