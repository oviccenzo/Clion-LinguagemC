#include "cstdio"

int main(){

    float notas[5];
    float media, soma;

    printf("");
    scanf("");

    printf("");
    scanf("");

    printf("");
    scanf("");

    //Nota 4
    printf("");
    scanf("");

    //Nota 5
    printf("");
    scanf("");
}

//#include <stdio.h>
//
//int main() {
//    float notas[5];
//    float media, soma;
//
//    printf("Digite as notas de 5 alunos: ");
//    scanf("%f", &notas[0]);
//    scanf("%f", &notas[1]);
//    scanf("%f", &notas[2]);
//    scanf("%f", &notas[3]);
//    scanf("%f", &notas[4]);
//
//    // Cálculo da soma e média (ainda não implementado no código original)
//    soma = notas[0] + notas[1] + notas[2] + notas[3] + notas[4];
//    media = soma / 5;
//
//    printf("A média das notas é: %.2f\n", media);
//
//    return 0;
//}
