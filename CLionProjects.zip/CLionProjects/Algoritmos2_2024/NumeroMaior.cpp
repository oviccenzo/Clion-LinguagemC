//18/11/2023
//exemplo 4:
//Comando if
#include <cstdio>
int main()
{
    int num;
    printf("Digite um numero: ");
    scanf("%d",&num);
    if(num>200){
        printf("\n\nO numero e maior que 200");
        printf("O numero e igual a 200");
    }
    if(num<10)
        printf("\n\nO numero e menor que 200");
    return 0;
}