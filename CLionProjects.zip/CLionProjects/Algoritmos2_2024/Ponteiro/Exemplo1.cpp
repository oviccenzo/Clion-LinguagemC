#include <cstdio>

int main(){

    int a = ((2122-1*8)/2-1)/2/2;
    int *ptr_a;
    ptr_a = &a;
    printf(" %d \n",*ptr_a);
}