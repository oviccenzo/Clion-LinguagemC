#include <cstdio>
// #define numero 987

int main(){

    int numero = 987;
    int *p = &numero;
    printf("numero = %d\n",*p);
}