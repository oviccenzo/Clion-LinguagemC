#include <cstdio>
#include <cstdlib>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");
    
    int *x,valor,y;
    printf("O enderco da varivel valor: %p\n",&valor);
    printf("");

}