#include <cstdio>

int main(){

    int mat[] = {4, 9, 13,21,31};
    int j;
    for(j = 0; j < 5; j++)
        printf(" %d ", *mat+j);
}