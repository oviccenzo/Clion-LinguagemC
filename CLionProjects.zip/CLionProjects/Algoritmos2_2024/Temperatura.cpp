//
// Created by Robert L Resende on 07/12/24.
//
#include "cstdio"

int main(){


    for (int n = 32; n <= 80; n++){
        printf("C° %d = F° %d \n",n, (9*n)/5 + 32);
    }

    return 0;
}