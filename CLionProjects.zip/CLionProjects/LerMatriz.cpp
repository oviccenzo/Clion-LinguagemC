#include <cstdio>

#define M 5
#define N 5

int encontrarMatriz(int matriz[M][N]){
    for(int i = 0; i < M; i++){
        for(int j = 0; j < N; j++){
            printf("Posicao da matriz(%d, %d)\n ", i + 1, j + 1,matriz[i][j]);
        }
    }
}

int main(){

    int matriz[M][N], num;

    for(int i = 0; i < M; i++){
        for(int j = 0; j < N; j++){
            printf("Elemento da matriz[%d][%d]: ", i + 1, j + 1);
            scanf("%d", &matriz[i][j]);
        }
    }


    printf("Digite um numero: ");
    scanf("%d",&num);

    printf("O resultado da matriz e: %d\n",num);

    encontrarMatriz(matriz,num);
}
