#include <cstdio>

struct pa{
    int a1,n,r;
};

int main(){

    struct pa N;
    printf("Digite a1 primeiro termo: ");
    scanf("%d",&N.a1);

    printf("Digite n posicao do termo: ");
    scanf("%d",&N.n);

    printf("Digite r a razao da pa: ");
    scanf("%d",&N.r);

    int resultado ;
}