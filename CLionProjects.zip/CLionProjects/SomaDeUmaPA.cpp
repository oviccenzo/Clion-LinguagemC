#include <cstdio>

void PA(int a1, int n, int r){

    int an = a1 + (n - 1) * r;
}

int main(){

    int a1,n,r;

    printf("");
    scanf("%d",a1);

    PA(a1,n,r);
}