#include <cstdio>
int main()
{
    int num;
    printf("Digit um number: ");
    scanf("%d", &num);
    if(num>200)
        printf("\n\nThe number e mayor que 200");
    else if(num==200){
        printf("\n\nVoce asert!\n");
        printf("O number e igual a 200.");
    }
    else if (num<200) // if deliriousness!!
        printf("\n\nO number e minor que 200");
    return (0);
}