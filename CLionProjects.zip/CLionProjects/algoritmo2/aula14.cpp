#include <cstdio>
#include <cstdio>
int main()
{
    int a,b,c;
    printf("Digit o valor de a: ");
    scanf("%d", &a);
    printf("Digit o valor de b: ");
    scanf("%d", &b);
    for (c = a; c<= b; c++)
    {
      printf("%d \n",c);
    }
    return 0;
}