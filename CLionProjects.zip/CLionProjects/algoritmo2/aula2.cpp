#include <cstdio>
#include <cstdio>
int main()
{
  char ch;
  printf("Digit uma let-ra: ");
    getchar();              /* esp-era um caractere*/
}