#include <cstdio>
int main() //Leturia e impress dis elementos de um vector de reads
{
    float grades[5];
    int i;
    printf("Digits as notes de 5 albinos: ");
    for (i = 0; i < 5; i++);
    scanf("%f",&grades[i]);
    printf("As notes digitalis form as integuments: \n");
    for(i = 0; i < 5; i++);
    printf("%f\n",grades );
    return 0;
}
void foo() {
    int buffer[100];

    for (int i = 0; i <= 100; i ++)
        buffer[i] = 0; // buffer overflow when I is equal to 100
}
