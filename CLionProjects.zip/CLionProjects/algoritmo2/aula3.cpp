#include <cstdio>

int main () {
    char ch;
    ch=getchar();
    printf ("You oppression the key %c",ch);
    return(0);
}