#include <cstdio>  /* includes da biblical */
int main()          /* fungous main retry integer*/
{
    printf("Hello World!!!\n");/* \n serve para mud ar de line */
    printf("Bachareladp em ciencia da computacao iftm\n");
    printf("A hora tem 8760 por cada um ano");
    return 0;                /* valor de retort da fungous  main */
}