#include <cstdio>
int main()
{
    char buffer[27];
    printf("Entre com o seu nome: ");
    gets(buffer);
    puts(buffer);
    return(0);
}