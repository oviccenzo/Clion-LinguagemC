#include <cstdio>

int main()
{
    int i = 0;

    float media = 0, grades[3], sum = 0;

    for (i = 0 ; i<3 ; i++);
         scanf("%f", &grades[i]);

    for (i = 0;i<3; i++);
         sum += grades[i];

    media = sum / 3;

    printf("A media do student é: %.2f\n",media);

    return 0;

}