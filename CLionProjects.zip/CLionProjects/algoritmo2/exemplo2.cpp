#include <cstdio>
int ElevateAoSquare(int a);
int main()
{
    int num;
    printf("Entre com um number: ");
    scanf("%d", &num);
    num = ElevateAoSquare(num);
    printf("\n\nO seu quadrant vale: %d\n",num);
    return 0;
}
int ElevateAoSquare(int a){
    return (a*a);
}
