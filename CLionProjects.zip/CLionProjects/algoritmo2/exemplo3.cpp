#include <cstdio>

void system(const char *string);

int main ()
{
int num;
for (num = 1; num < 100; num++ ) //initialization; condition; increment
{
printf ("Number = %d \n", num);
} system("PAUSE"); return 0;
}

void system(const char *string) {

}
