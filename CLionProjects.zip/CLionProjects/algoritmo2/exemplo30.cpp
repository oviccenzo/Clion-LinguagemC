//14/11/2023
#include <cstdio>
#include <cstdlib>
#include <cmath>
int main(int argc, char*argv[])
{
    int numero = 925;


    printf("A raz quadrado de %d e %f ",numero,
           sqrt(numero));

    printf("\n\n");
    return 0;
}