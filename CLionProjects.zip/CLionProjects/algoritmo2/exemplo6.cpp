#include <cstdio>
int main()
{
    float notas[5];
    float media, soma = 0;
    int i;
    printf("Digite as notas de 5 alunos: ");
    for(i=0;i<5;i++){
        scanf("%f",&notas[i]);
    }
}
