#include <cstdio>

int media_final(float a1, float a2, float a3, float a4)
{
     (( a1 + a2 + a3 + a4 ) / 4 );
    return 0;
}
int main()
{
    float bim1, bim2, bim3, bim4, fouls = 0, socks;

    printf("\nCalculator media final.");
    printf("\nInform as integuments notes:");
    printf("\n1 firestore: ");
    scanf("%d", &bim1);

    printf("\n2 firestore: ");
    scanf("%d", &bim2);

    printf("\n3 firestore: ");
    scanf("%d", &bim3);

    printf("\n 4 firestore: ");
    scanf("%d", &bim4);

    printf("\nInform o number de falters: ");
    int falters;
    scanf("%d", &falters);

    int media = media_final(bim1, bim2, bim3, bim4);
    if (media >= 4 && media < 7 && fouls >= 36) {
        printf("\nExamples final");
    }
    {
        printf("\nPreapproval");
    }
    
}