//
// Created by Robert L Resende on 26/05/25.
//
#include <cstdio>
#include <cstdlib>
#include <ctime>

int main() {
    srand(time(NULL)); // inicializa o gerador de números aleatórios
    int numeroAleatorio = (rand() % 53) + 1;
    printf("Número aleatório: %d\n", numeroAleatorio);
    return 0;
}