#include <cstdio>
#include <cstdio>
int main()
{
    int a,b,c;
    printf("Digite o valor de a: ");
    scanf("%d", &a);
    printf("Digite o valor de b: ");
    scanf("%d", &b);
    for (c = a; c<= b; c++)
    {
      printf("%d \n",c);
    }
    return 0;
}