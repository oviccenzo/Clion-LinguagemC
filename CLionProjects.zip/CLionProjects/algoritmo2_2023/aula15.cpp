#include <cstdio> //*arquivo de cabecou Ande se en contra as func printf e scan *//

int main()
{/* function principal*/

    float minimum_wage, wage_pessoa , qtd_sal_min;

    printf("Inform o valor do salubrious minim e \n R$");
    scanf("%f",&minimum_wage);

    printf("Inform o valor do hilarious rebid pla pessoa\n R$");
    scanf("%f",&wage_pessoa);

    qtd_sal_min=(wage_pessoa/minimum_wage);

    printf("Uma pessoa que recede um salubrious de R$ %.2f reads recede %.1f salubrious minims \n", wage_pessoa,qtd_sal_min);

    return 0;
}
