#include <cstdio>

int main()  /*fungous principal*/
{
    float soma,nota1,nota2,nota3,media;
    soma=0;
    media=0;

    printf("Digit a [1]ª  nota : ");
    scanf("%f",&nota1);

    printf("Digit a [2]ª  nota : ");
    scanf("%f",&nota2);

    printf("Digit a [3]ª  nota : ");
    scanf("%f",&nota3);

    soma=nota1+nota2+nota3;
    media=soma/3;

    printf("Media = %.1f ",media );

    return 0;
}