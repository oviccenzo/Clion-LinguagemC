#include <cstdio>
int main()
{
    char string[100];
    printf("Enter a string: ");
    gets(string);
    printf("\n\nYou typed %s", string);
    return(0);
}