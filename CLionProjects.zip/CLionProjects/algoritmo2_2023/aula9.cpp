#include <cstdio>
int main()
{
    int num;
    printf ("Digit um number: ");
    scanf("%d",&num);
    if(num==200){
        printf("");
        printf("O number e igual a 200.\n");
    }
    else{
        printf("\n\nVoce error!\n");
        printf("O number e different de 200.\n");
    }
    return(0);
}