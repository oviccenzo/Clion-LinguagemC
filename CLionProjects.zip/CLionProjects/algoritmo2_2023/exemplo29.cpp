//22/10/2023 As 9h36m
#include <cstdio>
int main()
{
    int option;
    const int num1 = 0;
    const int num2 = 0;
    num1,
    num2;

    {
      printf("\t\t\nEscolha a sua operacoa\n");
      printf("0.sair\n");
      printf("");
    }
}