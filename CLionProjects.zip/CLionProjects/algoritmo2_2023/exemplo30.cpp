//14/11/2023
#include <cstdio>
#include <cstdlib>
#include <cmath>
int main(int argc, char*argv[])
{
    int numero;


    printf("Digite um numero: ");
    scanf("%d",&numero);

    printf("A raz quadrado de %d e %f ",numero,
           sqrt(numero));

    printf("\n\n");
    return 0;
}