#include <cstdio>

int main()
{
    int age, weight;
    float height;

    printf("Digite a idade: ");
    scanf("%d", &age);
    printf("Digite a altura: ");
    scanf("%f",&weight);
    printf("Digite o peso: ");
    scanf("%d",&height);

    printf("Idade: %d\n",age);
    printf("Altura: %f\n",weight);
    printf("Peso: %d\n",height);
}