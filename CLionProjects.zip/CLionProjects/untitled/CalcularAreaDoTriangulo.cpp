#include <cstdio>
int main()
{
    int b,h;

    printf("A area base(B): ");
    scanf("%d",&h);

    printf("A area da altura(H): ");
    scanf("%d",&b);

    int a = (b * h) / 2;

    printf("O resultado da area do triangulo é: %.2d",a,"cm");

    return 0;
}