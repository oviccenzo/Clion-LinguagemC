//
// Created by Robert L Resende on 05/10/24.
//
#include <stdio.h>

int main(){

    int j,i;
    for(j = 5; j >= 1; j--){
        printf("j = %d\n",j);
    }
//    int i,j,k;
//    for(i = 1; i <= 40; i++) {
//        for (j = 3; j > 0; j--)
//            k = i + j;
//            printf("%d + %d = %d\n", i, j, k);
//        }

}