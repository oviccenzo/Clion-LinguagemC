#include <cstdio>
int main(){

    int numero;

    printf("Digite o mes do ano: ");
    scanf("%d",&numero);

    if(numero == 1){
        printf("O mês de Janeiro\n");
    } if(numero == 2){
        printf("O mês de Fevereiro\n");
    } if(numero == 3){
        printf("O mês de Março\n");
    } if(numero == 4){
        printf("O mês de Abril\n");
    } if(numero == 5){
        printf("O mês de Maio\n");
    } if(numero == 6){
        printf("O mês de Junho\n");
    } if(numero == 7){
        printf("O mês de Julho\n");
    } if(numero == 8){
        printf("O mês de Agosto\n");
    } if(numero == 9){
        printf("O mês de Setembro\n");
    } if(numero == 10){
        printf("O mês de Outubro\n");
    } if(numero == 11){
        printf("O mês de Novembro\n");
    } if(numero == 12){
        printf("O mês de Dezembro\n");
    } if (numero < 1 && numero > 12){
        printf("Se o numero é inválido");
    }
}