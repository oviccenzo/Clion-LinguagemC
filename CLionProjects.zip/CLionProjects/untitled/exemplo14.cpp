//18/11/2023
//Exemplo 2:
#include <cstdio>
int main()
{
    int num, soma;
    soma = 0;
    num = 1;
    while(num < 10){
        soma = soma + num; //equivalente a: soma += num;
        printf("Numero = %d\n",num);
        num += 2;
    }
    printf("Soma = %d\n",soma);
    return 0;
}