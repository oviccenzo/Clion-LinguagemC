//18/11/2023
//Comando do-while
//Exemplo 3:
#include <cstdio>
int main()
{
    int a = 1;
    do {
        a = a + 1;
        printf("Valor de a: %d\n",a);
    } while(a < 20);
    return 0;
}