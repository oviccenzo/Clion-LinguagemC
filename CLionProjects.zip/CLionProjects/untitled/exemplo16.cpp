//18/11/2023
//Parte 9
//Manipulacao de Strings
//A funcao gets()
//Exemplo 1:
#include <cstdio>
int main()
{
    char string[100];
    printf("Digite o seu nome: ");
    gets(string);
    printf("\n\nOla %s\n",string);
    return (0);
}