//18/11/2023
//strcpy e uma copia de strcpy-origem para a string-destino
//Exemplo 2:
#include <cstdio>
#include <cstring>
int main(){
    char str1[100],str2[100],str3[100];
    printf("Entre com uma string: ");
    strcpy(str2,str3);
    strcpy(str3,"Voce digitou a string");
    printf("\n\n%s%s",str3,str2);
    return (0);
}