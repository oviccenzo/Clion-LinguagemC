//18/11/2023
//Exemplo 3: A strcat euma string de origem ate o destino da string
//strcat
#include <cstdio>
#include <cstring>
int main(){
    char str1[50],str2[50];
    strcpy(str2,"Voce digitou a string: ");
    printf("\n\n%s",str2);
    return (0);
}