//18/11/2023 a 19/11/2023
//A strlen e uma funcao que retorna o comprimento da string fornecida.
//strlen
//Exemplo 4:
#include <cstdio>
#include <cstring>
int main(){
    int size; char str[100];
    size = strlen(str);
    printf("\n\nA string que voce digitou tem tamanho %d",size);
    return 0;
}