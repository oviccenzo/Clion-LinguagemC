//19/11/2023
//O programa usa a funcao struct pessoa trabalho e idade
//Exemplo 2:
#include <cstdio>
#include <cstdlib>
struct pessoa{ //definicao do tipo pessoa
    int idade;
    char trabalha;
    char estuda;
};

int main()
{
    struct pessoa A,B;
    A.idade = 18;
    A.trabalha = 's';
    A.estuda = 'n';
    B = A; //varivel B recebe todos os campos de A
    printf("Pessoa A: %d %c %c \n",A.idade,A.trabalha,A.estuda);
    printf("Pessoa B: %d %c %c \n",B.idade,B.trabalha,B.estuda);
    system("PAUSE");
    return 0;
}