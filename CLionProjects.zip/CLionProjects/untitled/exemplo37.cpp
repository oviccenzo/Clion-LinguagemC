//20/11/2023
//parte 15:
//ponteiros
//Exemplo : parametros por referencia
#include <cstdio> //Programa ordena vetor bugado

void troca(int a, int b);

int main()
{
    int a[10];
    int i, j, n = 5;

    for ( i = 0; i < n; i++)
        scanf("%d",&a[i]);
    for(j = 0; j < n; i++)
        if(a[i],a[i+j])
            troca(a[i], a[i+1]);
    for(i = 0; i < n; i++)
        printf("%d\n",a[i]);
}
void troca(int a, int b) // bigado
{
    int temp;
    temp = a;
    a = b;
    b = temp;
}