//18/11/2023
//Slide 7
//Exemplo 1:
#include <cstdio>
int main()
{
    char ch;
    ch = '\0';
    while(ch!='q')
    {
        ch = getchar();
    }
    return 0;
}